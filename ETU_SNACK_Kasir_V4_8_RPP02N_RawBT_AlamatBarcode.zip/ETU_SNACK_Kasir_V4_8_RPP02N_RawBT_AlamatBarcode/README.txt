ETU SNACK KASIR V4.8 — RPP02N / RAWBT + ALAMAT TOKO + BARCODE RAPI

Isi:
- index.html: aplikasi ETU SNACK Kasir berbasis HTML.

Perubahan:
1. Mode cetak RPP02N melalui aplikasi RawBT (Bluetooth klasik/SPP), karena Web Bluetooth di browser/WebView umumnya tidak dapat mengakses Bluetooth Classic SPP secara langsung.
2. Tombol tes cetak mengirim contoh struk melalui skema RawBT.
3. Pengaturan alamat toko dapat diedit dan disimpan; alamat tampil pada struk dan label barcode.
4. Tata letak label barcode dirapikan: kolom lebih stabil, jarak konsisten, teks nama/alamat membungkus, barcode tetap di tengah.
5. Fitur lain dari ZIP sumber tetap dipertahankan.

CARA SETUP PRINTER RPP02N:
1. Cadangkan data dari aplikasi lama terlebih dahulu melalui fitur cadangan/ekspor.
2. Pada Pengaturan Bluetooth Android, nyalakan printer RPP02N dan pasangkan. PIN umumnya 0000; bila tidak cocok, cek kartu/manual printer.
3. Pasang aplikasi RawBT dari Google Play: https://play.google.com/store/apps/details?id=ru.a402d.rawbtprinter
4. Buka RawBT dan pilih/pasangkan printer RPP02N di pengaturan RawBT. Tes cetak dari aplikasi RawBT terlebih dahulu.
5. Buka ETU SNACK, masuk Pengaturan > Printer Struk, tekan AKTIFKAN RPP02N / RAWBT, lalu TES CETAK.
6. Bila berhasil, Auto cetak struk bisa diaktifkan. Tetap uji satu transaksi kecil dahulu.

CATATAN PENTING:
- File ini berbasis HTML/WebView, bukan proyek Android native. Karena itu koneksi Bluetooth klasik memerlukan aplikasi pendamping seperti RawBT; ZIP ini tidak menambahkan Bluetooth SPP native ke APK pembungkus.
- Pemanggilan RawBT harus diizinkan oleh browser/WebView pembuat APK dan aplikasi RawBT harus terpasang serta sudah dikonfigurasi.
- Pencetakan fisik belum bisa diuji dari lingkungan ini, jadi keberhasilan akhir harus dites pada HP dan printer RPP02N yang sebenarnya.
- Simpan cadangan data sebelum mengganti file/index.html pada pembuat APK.
